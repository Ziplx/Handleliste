
//creating a Data Model Class
class EmpModelClass(val id: Int, val name: String, val email: String)