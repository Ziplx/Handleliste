

class DatabaseClass(val id: Int, val tittel: String, val varer: String)