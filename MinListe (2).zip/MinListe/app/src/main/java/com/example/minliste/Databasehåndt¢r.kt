import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.database.sqlite.SQLiteOpenHelper
import com.example.minliste.MainActivity


class Databasehåndtør(context: MainActivity) :
    SQLiteOpenHelper(context, DATABASE_NAVN, null, DATABASE_VERSION) {

    companion object {
        private val DATABASE_VERSION = 1
        private val DATABASE_NAVN = "Handlelistedatabase"

        private val TABLE_VARER = "Varetabell"

        private val KEY_ID = "_id"
        private val KEY_TITTEL = "tittel"
        private val KEY_VARER = "varer"
    }

    override fun onCreate(db: SQLiteDatabase?) {

        val CREATE_CONTACTS_TABLE = ("CREATE TABLE " + TABLE_VARER + "("
                + KEY_ID + " INTEGER PRIMARY KEY," + KEY_TITTEL + " TEXT,"
                + KEY_VARER + " TEXT" + ")")
        db?.execSQL(CREATE_CONTACTS_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db!!.execSQL("DROP TABLE IF EXISTS $TABLE_VARER")
        onCreate(db)
    }

    fun LeggtilHandleliste(emp: DatabaseClass): Long {
        val db = this.writableDatabase

        val contentValues = ContentValues()
        contentValues.put(KEY_TITTEL, emp.tittel)
        contentValues.put(KEY_VARER, emp.varer)
        val success = db.insert(TABLE_VARER, null, contentValues)

        db.close()
        return success
    }



    fun seListe(): ArrayList<DatabaseClass> {

        val dblist: ArrayList<DatabaseClass> = ArrayList<DatabaseClass>()
        val selectQuery = "SELECT  * FROM $TABLE_VARER"
        val db = this.readableDatabase
        var cursor: Cursor? = null

        try {
            cursor = db.rawQuery(selectQuery, null)

        } catch (e: SQLiteException) {
            db.execSQL(selectQuery)
            return ArrayList()
        }

        var id: Int
        var tittel: String
        var innhold: String

        if (cursor.moveToFirst()) {
            do {
                id = cursor.getInt(cursor.getColumnIndex(KEY_ID))
                tittel = cursor.getString(cursor.getColumnIndex(KEY_TITTEL))
                innhold = cursor.getString(cursor.getColumnIndex(KEY_VARER))

                val database = DatabaseClass(id = id, tittel = tittel, varer = innhold)
                dblist.add(database)

            } while (cursor.moveToNext())
        }
        return dblist
    }


    fun OppdaterListe(emp: DatabaseClass): Int {
        val db = this.writableDatabase
        val Innholdsverdier = ContentValues()
        Innholdsverdier.put(KEY_TITTEL, emp.tittel)
        Innholdsverdier.put(KEY_VARER, emp.varer)

        val success = db.update(TABLE_VARER, Innholdsverdier, KEY_ID + "=" + emp.id, null)

        db.close()
        return success
    }

    fun Slettliste(emp: DatabaseClass): Int {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(KEY_ID, emp.id)
        val success = db.delete(TABLE_VARER, KEY_ID + "=" + emp.id, null)

        db.close()
        return success
    }
}