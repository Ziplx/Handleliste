package com.example.minliste

import DatabaseClass
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.vare_liste.view.*

class ItemAdapter(val context: Context, val items: ArrayList<DatabaseClass>) :
    RecyclerView.Adapter<ItemAdapter.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(context).inflate(
                R.layout.vare_liste,
                parent,
                false
            )
        )
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val item = items.get(position)

        holder.tvTittel.text = item.tittel
        holder.tvInnhold.text = item.varer

        if (position % 2 == 0) {
            holder.llMain.setBackgroundColor(
                ContextCompat.getColor(
                    context,
                    R.color.colorLightGray
                )
            )
        } else {
            holder.llMain.setBackgroundColor(ContextCompat.getColor(context, R.color.colorWhite))
        }

        holder.lwEndre.setOnClickListener { view ->

            if (context is MainActivity) {
                context.Oppdateringsdialog(item)
            }
        }

        holder.lwSlett.setOnClickListener { view ->

            if (context is MainActivity) {
                context.SlettlisteDialog(item)
            }
        }
    }


    override fun getItemCount(): Int {
        return items.size
    }


    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        val llMain = view.llMain
        val tvTittel = view.Listenavn
        val tvInnhold = view.Innholdvare
        val lwEndre = view.kpEndre
        val lwSlett = view.kpSlett
    }
}